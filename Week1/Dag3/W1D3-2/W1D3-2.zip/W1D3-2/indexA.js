const makeSandwichWithCheese = function() {
  console.log("Take a slice of bread");
  console.log("Put butter on bread");
  console.log("Lay cheese on butter");
  console.log("Second bread on top");
  console.log("Cut in half");
};

makeSandwichWithCheese();
