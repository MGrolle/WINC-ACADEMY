const makeSandwich = function(topping) {
  console.log("Take a slice of bread");
  console.log("Put butter on bread");
  console.log("Lay " + topping + " on butter");
  console.log("Second bread on top");
  console.log("Cut in half");
  console.log("There you go, a " + topping + " sandwich");
};

makeSandwich("ham");
makeSandwich("tuna");
