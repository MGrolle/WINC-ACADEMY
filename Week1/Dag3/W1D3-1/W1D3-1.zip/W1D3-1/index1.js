const person = {
  name: "Marijn",
  age: 21,
  evaluations: [7, 10, 9]
};

console.log(person);
console.log(person.name);
console.log(person.age);
console.log(person["name"]);
console.log(person["age"]);
console.log(person.evaluations);
