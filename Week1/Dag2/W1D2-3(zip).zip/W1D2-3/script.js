console.log("Hallo Winc Academy studenten");

// Dit is een grote som.
let multiplication = 1230941 * 1823794;
console.log("multiplication:", multiplication);

let divide = 637263 / 54;
console.log("divide:", divide);
